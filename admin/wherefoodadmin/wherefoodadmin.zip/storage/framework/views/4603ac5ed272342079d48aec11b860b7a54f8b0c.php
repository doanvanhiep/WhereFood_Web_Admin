<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Form trong Laravel 5</title>
</head>
<body>
	<h1>Them Bai Viet Moi</h1>
	{<?php echo Form::open(); ?>}
		<?php echo Form::label('name','Name:'); ?>

		<?php echo Form::text('name'); ?> <br />
 
		<?php echo Form::label('author','Author:'); ?>

		<?php echo Form::text('author'); ?> </br>
 
		<?php echo Form::submit('Them moi'); ?>

	{<?php echo Form::close(); ?>

</body>
</html><?php /**PATH C:\wamp64\www\WhereFood_Web_Admin\admin\wherefoodadmin\resources\views/xe.blade.php ENDPATH**/ ?>